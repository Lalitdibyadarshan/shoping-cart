import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { Ingredient } from 'src/app/shared/models/ingredient.model';
import { ShoppingListService } from '../shopping-list.service';


@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit {
  @ViewChild('nameInput', {static: false}) ingNameRef : ElementRef;
  @ViewChild('amountInput', {static: false}) ingAmountRef : ElementRef;
  @Output() onAddIngredient = new EventEmitter<Ingredient>()
  constructor(private shoppingListService: ShoppingListService) { }

  ngOnInit() {
  }

  onAdd() {
    const name = this.ingNameRef.nativeElement.value;
    const amount = this.ingAmountRef.nativeElement.value;
    this.shoppingListService.addIngredients(new Ingredient(name, amount));
  }
}

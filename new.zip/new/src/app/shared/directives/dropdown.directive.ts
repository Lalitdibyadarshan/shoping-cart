import { Directive, HostListener, ElementRef, Renderer2 } from '@angular/core';

@Directive({
    selector: '[appDropdownDirective]'
})
export class DropdownDirective {
    isOpen =  false;
    constructor(private el: ElementRef, private renderer: Renderer2) {};

    @HostListener('document:click', ['$event']) 
    toggleOpen(event: Event) {
        this.isOpen = this.el.nativeElement.contains(event.target) ? !this.isOpen : false;;
        let menu = this.el.nativeElement.querySelector('#menu');
        this.isOpen ? this.renderer.addClass(menu, 'show') : this.renderer.removeClass(menu, 'show');
    }
}
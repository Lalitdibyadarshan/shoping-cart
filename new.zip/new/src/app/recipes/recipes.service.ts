import { Injectable, EventEmitter } from '@angular/core';
import { Recipe } from '../shared/models/recipe.model';
import { ImageDirectory } from '@images';
import { Ingredient } from '../shared/models/ingredient.model';

@Injectable({
  providedIn: 'root'
})
export class RecipesService {
  selectedRecipe = new EventEmitter<Recipe>();
  private recipes: Recipe[] = [
    new Recipe('Butter Paneer', 'Yummy', ImageDirectory.BUTTERPANEER, [new Ingredient('Butter',"100gm"), new Ingredient('Paneer',"500gm")]),
    new Recipe('Kheer', 'Sweeeeeet ❤', ImageDirectory.KHEER, [new Ingredient('Milk',"1lt"), new Ingredient('Rice',"100gm")])
  ];
  constructor() { }

  
  getRecipes(): Recipe[] {
    return this.recipes.slice();
  }
  
}

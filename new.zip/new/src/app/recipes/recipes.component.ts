import { Component, OnInit } from '@angular/core';
import { Recipe } from '../shared/models/recipe.model';
import { RecipesService } from './recipes.service';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import * as fileSaver from 'file-saver';
import { of, from } from 'rxjs';
import { mergeMap } from 'rxjs/operators'
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css']
})
export class RecipesComponent implements OnInit {
  selectedRecipe: Recipe;
  country = [];
  myForms: FormGroup = new FormGroup({});

  constructor(private recipeService: RecipesService, private http: HttpClient) { }
  ngOnInit() {
    this.myForms.addControl('myName', new FormControl('avc'))
    this.onSelectRecipe();
    //this.downloadFile();
    //this.getcountrys();
  }

  onSubmit() {
    //this.myForms.value.name = new
    console.log(this.myForms);
  }

  onSelectRecipe() {
      this.recipeService.selectedRecipe.subscribe(
        (recipe: Recipe) => {
          this.selectedRecipe = recipe;
        }
      );
  }

  // getcountrys() {
  //   const con = ['india', 'us'];
  //   const response = from(con).pipe(
  //     mergeMap((country) => {
  //       return this.http.get(`https://restcountries.eu/rest/v1/name/${country}`)
  //     })
  //   );
  //   response.subscribe(data => {
  //     this.country.push(data);
  //     console.log(this.country)
  //   });
  // }

  // downloadFile() {
  //  // window.open('http://localhost:4502/photoshop-cc-javascript-ref-2019.pdf');
  //   this.http.get('http://localhost:4502/photoshop-cc-javascript-ref-2019.pdf')
  //     .subscribe(response => {
  //       const blob = new Blob([response], {type: 'application/pdf'});
  //       const href = window.URL.createObjectURL(blob);
  //       window.open(href);
  //       fileSaver.saveAs(blob, 'abc');
  //     }, err => {
  //       console.log('404 file not found');
  //     });
  // }


}

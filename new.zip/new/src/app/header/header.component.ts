import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { ShoppingListService } from '../shopping-list/shopping-list.service';
import { Ingredient } from '../shared/models/ingredient.model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  shoppingListItems: number;
  constructor(private slService: ShoppingListService) { }

  ngOnInit() {
    this.shoppingListItems = this.slService.getIngredients().length;
    this.slService.addedIngredient.subscribe((list: Ingredient[]) => {
      this.shoppingListItems = list.length;
    });
  }
}

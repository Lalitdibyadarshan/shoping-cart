import { BaseUrls } from './baseUrls.enum';

export class ImageDirectory {
    static BUTTERPANEER = BaseUrls.image + 'butterPaneer.jpg';
    static KHEER = BaseUrls.image + 'kheer.jpg'
}
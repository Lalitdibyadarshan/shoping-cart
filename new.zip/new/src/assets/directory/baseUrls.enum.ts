export enum BaseUrls{
    image = 'assets/images/'
}